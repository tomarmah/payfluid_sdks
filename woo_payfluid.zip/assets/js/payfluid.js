jQuery(function ($) {

    var payfluid_submit = false;

    if ('embed' === wc_payfluid_params.pay_page_type) {

        wcPayfluidEmbedFormHandler();

    } else {

        jQuery('#payfluid-payment-button').click(function () {
            return wcPayfluidFormHandler();
        });

        jQuery('#payfluid_form form#order_review').submit(function () {
            return wcPayfluidFormHandler();
        });

    }

    function wcPayfluidFormHandler() {

        if (payfluid_submit) {
            payfluid_submit = false;
            return true;
        }

        var $form = $('form#payment-form, form#order_review'),
                payfluid_txnref = $form.find('input.payfluid_resp');


        payfluid_txnref.val('');

        var amount = Number(wc_payfluid_params.amount);

        var payfluid_callback = function (response) {
            //console.log('&&&&&&&&payfluid_callback::: '+response);
            $form.append('<input type="hidden" class="payfluid_resp" name="payfluid_resp" value="' + response + '"/>');
            payfluid_submit = true;

            $form.submit();

            $('body').block({
                message: null,
                overlayCSS: {
                    background: '#fff',
                    opacity: 0.6
                },
                css: {
                    cursor: "wait"
                }
            });
        };

        //console.log('&&&&&&&&params:::'+wc_payfluid_params.pay_url+' --- '+wc_payfluid_params.email)
        //var handler = PayfluidPop.setPayfluidURL(wc_payfluid_params.pay_url);
        var handler = PayfluidPop.setup({
            key: wc_payfluid_params.key,
            paylink: wc_payfluid_params.pay_url,
            email: wc_payfluid_params.email,
            amount: amount,
            ref: wc_payfluid_params.reference,
            currency: wc_payfluid_params.currency,
            callback: payfluid_callback,
            onClose: function () {
                $(this.el).unblock();
            }
        });
        //console.log('&&&&&&&&about to call openiframe')
        handler.openIframe();

        return false;

    }

    function wcPayfluidEmbedFormHandler() {

        if (payfluid_submit) {
            payfluid_submit = false;
            return true;
        }

        var $form = $('form#payment-form, form#order_review'),
                payfluid_txnref = $form.find('input.payfluid_txnref');

        payfluid_txnref.val('');

        var amount = Number(wc_payfluid_params.amount);

        var payfluid_callback = function (response) {

            $form.append('<input type="hidden" class="payfluid_txnref" name="payfluid_txnref" value="' + response.trxref + '"/>');

            $('#payfluid_form a').hide();

            payfluid_submit = true;

            $form.submit();

            $('body').block({
                message: null,
                overlayCSS: {
                    background: "#fff",
                    opacity: 0.8
                },
                css: {
                    cursor: "wait"
                }
            });

        };

        var handler = PayfluidPop.setup({
            key: wc_payfluid_params.key,
            paylink: wc_payfluid_params.pay_url,
            email: wc_payfluid_params.email,
            amount: amount,
            reference: wc_payfluid_params.reference,
            currency: wc_payfluid_params.currency,
            container: "payfluidWooCommerceEmbedContainer",
            callback: payfluid_callback,
            trxStatusCallbackURL: payfluid_callback,
            onClose: function () {
                $(this.el).unblock();
            }
        });
        handler.openIframe();
        return false;
    }

});